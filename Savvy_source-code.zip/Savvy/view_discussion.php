<?php

session_start();

$user=$_SESSION['user'];
$courseInfo=$_SESSION['courseInfo'];
$AssessmentName=$_SESSION['AssessmentName'];
$DueDate = $_SESSION['DueDate'];
$TotalScore = $_SESSION['totalScore'];
$Question = $_SESSION["Question"];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discussion</title>
    <link rel="stylesheet" href="discussion.css">
</head>
<body>
<div>
   <h2>Course : <?php echo $courseInfo  ?></h2> <h2>Discussion Name : <?php echo $AssessmentName  ?></h2><h2>Due Date : <?php echo $DueDate  ?></h2><h2>Total Score : <?php echo $TotalScore  ?></h2>
</div>
    <main>
        
    <div class="container"></div>
    <div  class="Question_for_all_types">
                <h3>Question:</h3>
                <p name="Question" id="Question"  ?>
                <?php echo $Question  ?>
</p>
            </div>   
            
       
    <div   class="discussion_answer" >
            <h3>Answer:</h3>
             <textarea rows="10" cols="60" name="discussion_ans" id="discussion_ans" placeholder="Type Answer here"> </textarea>
        </div>
        <button id="discussion_ans_button" value="discussion_ans_button" name="view_discussion_ans_button">Submit</button>
        </main>
<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>
<?php
   if(isset($_POST['edit_button'])) {
    $_SESSION['moduleName'] = $_POST["module_name"];
    header("Location:editModule.php");
}       
?>
