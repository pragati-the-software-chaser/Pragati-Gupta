<?php
require 'DB_Configuration/Configuration.php';
session_start();


$user=$_SESSION['user'];
$user_email=$_SESSION['email'];
$courseName = $_SESSION['courseInfo'] ;

$quiz_name = $_SESSION['AssessmentName'];

try{
    
    $dsn = 'mysql:host=localhost;dbname=savvy_db';
    $db= new PDO($dsn,'root','');
    $query= "select * from assessment_info WHERE courseName= :courseName and Assessment_Type = :type and Assessment_Name = :name";
    $statement = $db->prepare($query);
    $statement->bindValue(':courseName',$courseName);
    $statement->bindValue(':type','Quiz');
    $statement->bindValue(':name',$quiz_name);
    $statement->execute();
    $assessmentlist=$statement->fetchAll();
    foreach ($assessmentlist as $assessment) :
       $Due_Date = $assessment["Due Date"];
       $Total_score = $assessment["Total Score"];
    endforeach;
    

    $statement->closeCursor();  

    $query= "select * from test_info WHERE Assessment_Name= :name";
    $statement = $db->prepare($query);
    $statement->bindValue(':name',$quiz_name);
    $statement->execute();
    $questionlist=$statement->fetchAll();

    $statement->closeCursor();  
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiple Choice</title>
    <link rel="stylesheet" href="Multiple_choice_Question.css">
</head>
<body>
<h1>Test/Create Test/Name of the Test</h1><br>
    
       
       <b><center> <lable for = "course_name">Course Name:</lable><?php echo $courseName; ?></b>
       <b>  <p> <lable for = "quiz_name">Quiz Name: </lable><?php echo $quiz_name;   ?></p></b>
       <b>  <p><lable for = "dute_date">Due Date: </lable><?php echo $Due_Date;  ?></p></b>
       <b>  <lable for = "total_score">Total Score: </lable><?php echo $Total_score;  ?></b></center>
       <div class="container_of_multiple_questions">
            <form method="POST">
            <?php $question_number = 1; ?>
            <?php foreach ($questionlist as $question): ?>
            
            <div  class="Question_for_all_types">
                <p>Question: <?php echo $question_number; ?> <?php echo $question['Question']; ?></p>
            </div>   
            <?php if ($question['Question_Type'] == "MultiChoice"): ?>
            <div  class="option_of_multiple_choice_questions">
            <h3>Answer:</h3>
                <label for="answer_a">A.</label>
                <?php if (!$question['Option1'] == NULL): ?>
                <input type="text" name="answer_a" id="answer_a" value = "<?php echo $question['Option1']; ?>" ><br>
                <?php endif ; ?>
                <?php if (!$question['Option2'] == NULL): ?>
                <label for="answer_b">B.</label>
                <input type="text" name="answer_b" id="answer_b" value = "<?php echo $question['Option2']; ?>"><br>
                <?php endif ; ?>
                <?php if (!$question['Option3'] == NULL): ?>
                <label for="answer_c">C.</label>
                <input type="text" name="answer_c" id="answer_c" value = "<?php echo $question['Option3']; ?>"><br>
                <?php endif ; ?>
                <?php if (!$question['Option4'] == NULL): ?>
                <label for="answer_d">D.</label>
                <input type="text" name="answer_d" id="answer_d" value = "<?php echo $question['Option4']; ?>"><br><br>
                <?php endif ; ?> 
            </div>
            <?php endif ; ?>
            <?php if ($question['Question_Type'] == "Essay"): ?>
        <div  class="Essay" >
            <h3>Answer:</h3>
             <input type="text" name="answer_essay_question" id="answer_essay_question" placeholder="Type Answer here">
        </div>
        <?php endif; ?>
        <?php if ($question['Question_Type'] == "TrueFalse"): ?>
        <div  class="true_false">
            <h3>Answer:</h3>
                <label for="answer_a_true">A. True</label>
                <input type="radio" name="radio"  id="answer_a_true"  value="true">
                <label for="answer_b_false">B. False</label>
                 <input type="radio" name="radio" id="answer_b_false" value="False">
          </div>
          <?php endif; ?>
        <?php if(isset($_POST["matching_questions_button"])) :?>
        <div    class="matching_answers">
            <h3>Answer:</h3>
                    <label for="matching_option_a">A.</label>
                    <input type="text" name="matching_option_a" id="matching_option_a" placeholder="Type option A here">
                    <label for="matching_answer_a">a.</label>
                    <input type="text" name="matching_answer_a" id="matching_answer_a" placeholder="Type answer of A here"><br>
                    <label for="matching_option_b">B.</label>
                    <input type="text" name="matching_option_b" id="matching_option_b" placeholder="Type option B here">
                    <label for="matching_answer_b">b.</label>
                    <input type="text" name="matching_answer_b" id="matching_answer_b" placeholder="Type answer of B here"><br>
                    <label for="matching_option_c">C.</label>
                    <input type="text" name="matching_option_c" id="matching_option_c" placeholder="Type option C here">
                    <label for="matching_answer_c">c.</label>
                    <input type="text" name="matching_answer_c" id="matching_answer_c" placeholder="Type answer of C here"><br>
                    <label for="matching_option_d">D.</label>
                    <input type="text" name="matching_option_d" id="matching_option_d" placeholder="Type option D here">
                    <label for="matching_answer_d">d.</label>
                    <input type="text" name="matching_answer_d" id="matching_answer_d" placeholder="Type answer of D here"><br>
                    <button class="shuffle_button">Shuffle </button>
         </div>
         <?php endif; ?>
         <?php if ($question['Question_Type'] == "Fill in the blank"): ?>
        <div  >
            <h3>Answer:</h3>
            <input type="text" name="answer_fill_in_the_blanks" id="answer_fill_in_the_blanks" placeholder="Type Answer here"><br>
        </div>
    
<?php endif; ?>
<?php if ($question['Question_Type'] == "ShortAnswer"): ?>
<div   class="short_answer" >
    <h3>Answer:</h3>
     <input type="text" name="short_answer" id="short_answer" placeholder="Type Answer here">
</div>

<?php endif; ?>
<br>
<?php $question_number = $question_number + 1; ?>
<?php endforeach; ?>
<button class="shuffle_button" name = "submit_test">Submit Test</button><br><br>
</form>
</div>
    <footer>
        <ul>
            <li><a href="https://www.facebook.com/" >Facebook</a></li>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="contact_us.php">Contact Us</a></li>
        </ul>
   
    </footer>

</body>
</html>

<?php
if(isset($_POST['add_question'])) :
   header("Location:Multiple_choice_Question.php");
endif
?>