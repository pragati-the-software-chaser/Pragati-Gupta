<?php
require 'DB_Configuration/Configuration.php';
session_start();

$user=$_SESSION['user'];
$user_email=$_SESSION['email'];
$courselist= $_SESSION['courseList'];

    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Module</title>
    <link rel="stylesheet" href="viewModule.css">
</head>
<body>
   <h1>Module/View Modules</h1>
<main>

    <div class="container">

<form action="" method="post" enctype="multipart/form-data">


<lable for = "course_name" >Course Name:</lable>

<select class="option" name="course_name" id="course_name"  value = "<?php echo $_SESSION['courseInfo'];?>">
            <?php foreach ($courselist as $Courses): ?>
                <option><?php echo $Courses['courses']; ?> </option>
            <?php endforeach; ?>
            </select><br>
<button id="getModule" value="getModule" name="getModule">Get Module</button>
</form>
<?php
   if(isset($_POST['getModule'])) {
    try{
        $courseName = $_POST['course_name'];
        $_SESSION['courseInfo'] = $courseName;
        $dsn = 'mysql:host=localhost;dbname=savvy_db';
        $db= new PDO($dsn,'root','');
        $query= "select * from module_info WHERE courses= :course";
        $statement = $db->prepare($query);
        $statement->bindValue(':course',$courseName);
        $statement->execute();
        $modulelist=$statement->fetchAll();
        $statement->closeCursor();      
    }
    catch(Exception $e){
        $error_message = $e->getMessage();
        echo "<p>Error message: $error_message </p>";
    }
}

?>
<form  method="post" enctype="multipart/form-data">
<label for ="module_name">Module Name:</label>
<select class="option" name="module_name" id="module_name"  >
            <?php foreach ($modulelist as $module): ?>
                <option><?php echo $module['moduleName']; ?> </option>
            <?php endforeach; ?>
            </select><br>


<button id="edit_button" value="upload" name="edit_button">View Module</button>
<button id="add_topic_button" value="upload" name="add_topic_button">Add Topic</button>
</form>

</div>
</main>

<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>
<?php
   if(isset($_POST['edit_button'])) {
    try {
    $_SESSION['moduleName'] = $_POST["module_name"];
    header("Location:editModule.php");
    }
    catch(Exception $e){
        $error_message = $e->getMessage();
        echo "<p>Error message: $error_message </p>";
    }
}
if(isset($_POST['add_topic_button'])) {
    try {
    $_SESSION['moduleName'] = $_POST["module_name"];
    header("Location:add_topics.php");
    }
    catch(Exception $e){
        $error_message = $e->getMessage();
        echo "<p>Error message: $error_message </p>";
    }
}


?>
