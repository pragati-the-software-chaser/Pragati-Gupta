<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Savvy</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
    <div class="main_page">
   <button><a href="signup.php"> sign up</a></button>
   <button><a href="login.php">login</a></button>
   </div>

</body>
</html>