<?php
session_start();
$user=$_SESSION['user'];
$user_email=$_SESSION['email'];
    try{
    
        $dsn = 'mysql:host=localhost;dbname=savvy_db';
        $db= new PDO($dsn,'root','');
        $query= "select * from course_info WHERE email= :email";
        $statement = $db->prepare($query);
        $statement->bindValue(':email',$user_email);
        $statement->execute();
        $courselist=$statement->fetchAll();
        $_SESSION['courseList'] = $courselist;

        $statement->closeCursor();  
    }
    catch(Exception $e){
        $error_message = $e->getMessage();
        echo "<p>Error message: $error_message </p>";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
  
    <div class="navbar">
            <div class="container_nav">
                <div class="logo_div">
                <img src="professor1.jpg" alt="" class="logo">
                </div>
            <div class="navbar_links">
                <ul class="menu">
                    <li><?php echo "$user" ?></li>
                    
                    <li><a href="contact_us.php">Help</a></li>
                </ul>
            </div>
        </div>
    </div>
   <!--
           <div class="course">
            <lable for = "courses">Courses:</lable>
            <select class="option" name="courses" id="courses" >
            <?php
            /*
             foreach ($courselist as $Courses): ?>
            <option><?php echo $Courses['courses']; ?> </option>
            <?php endforeach; 
             */ 
            ?>
            </select><br>
            </div>
            -->
    <div class="container_dashboard"> 
    <div class="dashboard">         
    <ul>     
    <li>        
            <div class="couses_menu">
             <button class="couses_menu_button">Courses</button>
             <div class="couses_menu-content">
             <?php foreach ($courselist as $Courses): ?>
             <a href="#" class="couses_menu_href"><?php echo $Courses['courses']; ?></a>
             <?php endforeach; ?> 
            </div>
            </div>
        </li> 

        <li>        
            <div class="module">
             <button class="module_button">Module</button>
             <div class="module-content">
             <a href="create_module.php" class="create_module_href">Create Module</a>
             <a href="viewModule.php" class="edit_module_href">View Module</a>
             </div>
            </div>
        </li> 


        <li>       
            <div class="assessment">
            <button class="assessment_button">Assessment</button>
            <div class="assessment-content">
            <a href="create_assessment.php">Create Assessment</a>
            <a href="view_assessment.php">View Assessment</a>
            <a href="viewGrades.php">View Grades</a>
            </div>
            </div>
        </li> 
         </ul>
        </div>
        </div>

            <footer>
                <ul>
                    <li><a href="https://www.facebook.com/" >Facebook</a></li>
                    <li><a href="dashboard.php">Home</a></li>
                    <li><a href="contact_us.php">Contact Us</a></li>
                </ul>
            </footer>
   
</body>
</html>