<?php
try {
session_start();

$user=$_SESSION['user'];
$courseInfo=$_SESSION['courseInfo'];
$AssessmentName=$_SESSION['AssessmentName'];
$DueDate = $_SESSION['DueDate'];
$total_score = $_SESSION['totalScore'];
$dir = $user . "\\" . $courseInfo . "\\assessment" . "\\" . $AssessmentName;
$files = scandir($dir);
$current_dir = getcwd();

$target_dir = $current_dir . "\\" . $user . "\\" .$courseInfo . "\\assessment" . "\\" . $AssessmentName . "\\";
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Assignment</title>
    <link rel="stylesheet" href="editmodule.css">
</head>
<body>
    

<div>
   <h1>Course : <?php echo $courseInfo  ?></h1> <h1>Assignment Name : <?php echo $AssessmentName  ?></h1>
</div>
<main>
    <div class="container">
    <form action="" method="post" enctype="multipart/form-data">
<table class="center">
    <tr>
        <th class="content" >Content</th>
        <th> Due Date </th>
        <th> Total Score  </th>
        <th>Detele Content</th>
    </tr>
    <?php foreach ($files as $file): ?>
    <?php if ($file != ".." & $file != "."): ?>      
    <tr>
        <td class="downloadable_content"><a href="<?php echo $target_dir . $file; ?>"><?php echo $file; ?></a></td>
        <td> <?php echo $DueDate  ?></td>
        <td> <?php echo $total_score  ?></td>
        <td class="delete_button" ><button type="submit" name = "delete_button">Delete</button></td>
        <input hidden name = "targetFile" value = "<?php echo $target_dir . $file;?>">
    </tr>
    <?php endif; ?>
    <?php endforeach; ?>

</table>
<br>
  </form>
  <form action="" method="post" enctype="multipart/form-data">
<div class="uploadfile">


<label for ="upload_file">Upload File:</label>
<input type="file" id="fileToUpload" name="fileToUpload"><br>

<button id="upload_button" value="upload" name="upload_button">Upload File</button>


</div>
  </form>
</div>
</main>

<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>

<?php



if(isset($_POST['delete_button'])) {
    unlink($_POST['targetFile']);
    header("Location:editModule.php");

}

if(isset($_POST['upload_button'])) {
    try {
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    move_uploaded_file( $_FILES['fileToUpload']['tmp_name'], $target_file);
    header("Location:editModule.php");
    }
    catch(Exception $e){
        $error_message = $e->getMessage();
        echo "<p>Error message: $error_message </p>";
    }
}

?>