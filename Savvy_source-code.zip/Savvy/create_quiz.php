<?php
require 'DB_Configuration/Configuration.php';
session_start();


$user=$_SESSION['user'];
$user_email=$_SESSION['email'];
$courseName = $_SESSION['course_name'] ;

    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Quiz</title>
    <link rel="stylesheet" href="Create_Module.css">
</head>
<body>
<h1>Assessment / Create Quiz</h1><br>
<main>

    <div class="container">

<form  method="POST"  enctype="multipart/form-data">
    
<lable for = "course_name">Course Name: </lable><?php echo $courseName  ?><br>

</select><br>
<label for ="assignment_name">Quiz Name:</label>
<input type="text" name="quiz_name" id="assignment_name" placeholder="Type Quiz Name" required> <br><br>

<label for ="points">Total Points:</label>
<input type="text" name="points" id="points" placeholder="Type Points for the assessment" required> <br><br>

<label for ="date_assignment">Due Date</label>
<input type="date" name="date_assignment" id="date_assignment" required><br><br>

<label for ="fileToSet">Upload File:</label>
<input type="file" id="fileToSet" name="fileToSet">optional<br>

<button id="submit_button" name="create_quiz">Create Quiz</button>

</form >

</div>
</main>

<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>


<?php

if(isset($_POST['create_quiz'])) {

try {
    $user=$_SESSION['user'];

    $due_date =  $_POST['date_assignment'];
    $quiz_name = $_POST["quiz_name"];
    $score = $_POST["points"];

    $_SESSION['quiz_name'] = $quiz_name ;
    
    $query= "insert into assessment_info values('$courseName','Quiz','$quiz_name',NULL,'$due_date',$score)";

    $query_run= mysqli_query($con,$query);

    if($query_run)
    {
                        
        echo'<script type ="text/javascript"> alert("Quiz Created") </script>';
    }
    else 
    {
        echo'<script type ="text/javascript"> alert("Quiz Creation Failed Error!") </script>';
                
    }

    if ($_FILES["fileToSet"]["name"]) {
        $filename = $_FILES["fileToSet"]['tmp_name'];
        $file = @fopen($filename, 'r');

        $quiz = array();        // associated array containing '1. question1'=>answer array
        $answers = array();     // temporarily holds answers
        $question = '';         // temporarily holds questions
        $correctAns = '';
        while (($line = fgets($file)) != null) 
        {
            $line = trim($line);
            if ($line === '') continue;
            if (strpos($line,"Question")=== 0){
                if (count($answers) > 0 ){
                    
                    if(count($answers) == 1 ){
                        $query= "insert into test_info values('$quiz_name','$question','MultiChoice','$answers[0]',NULL,NULL,NULL,'$correctAns')";
                    }
                    if(count($answers) == 2 ){
                        $query= "insert into test_info values('$quiz_name','$question','MultiChoice','$answers[0]','$answers[1]',NULL,NULL,'$correctAns')";
                    }
                    if(count($answers) == 3 ){
                        $query= "insert into test_info values('$quiz_name','$question','MultiChoice','$answers[0]','$answers[1]','$answers[2],NULL,'$correctAns')";
                    }
                    if(count($answers) == 4 ){
                    $query= "insert into test_info values('$quiz_name','$question','MultiChoice','$answers[0]','$answers[1]','$answers[2]','$answers[3]','$correctAns')";
                    }
                    $query_run= mysqli_query($con,$query);
                    $answers = array();
                } 
                $tmpQuestion = explode(':',$line);
                $question = $tmpQuestion[1];
                $quiz[$question] = '';
            }
            else if(strpos($line,"Option")=== 0){
              
                $tmpOption = explode(':',$line);
                $answers[] = $tmpOption[1];
            }
            else if(strpos($line,"Correct")=== 0){
                $tmpCorrectAns = explode(':',$line);
                $correctAns = $tmpCorrectAns[1];
            }
            else {
            if (count($answers) == 0 ){
                $question = $question . $line;
            }
            else{
                $lastkey = array_key_last($answers);
                $lastkeyvalue = $answers[$lastkey];
                $answers[$lastkey] = $lastkeyvalue + $line;
            }
            }
        
        }
        if (count($answers) > 0 ){
            print_r($answers);
            if(count($answers) == 1 ){
                $query= "insert into test_info values('$quiz_name','$question','MultiChoice','$answers[0]','NULL,'NULL','NULL','$correctAns')";
            }
            if(count($answers) == 2 ){
                $query= "insert into test_info values('$quiz_name','$question','MultiChoice','$answers[0]','$answers[1]','NULL','NULL','$correctAns')";
            }
            if(count($answers) == 3 ){
                $query= "insert into test_info values('$quiz_name','$question','MultiChoice','$answers[0]','$answers[1]','$answers[2]','NULL','$correctAns')";
            }
            if(count($answers) == 4 ){
            $query= "insert into test_info values('$quiz_name','$question','MultiChoice','$answers[0]','$answers[1]','$answers[2]','$answers[3]','$correctAns')";
            }
            $query_run= mysqli_query($con,$query);
            $answers = array();
        } 

        echo'<script type ="text/javascript"> alert("Quiz Created") </script>';
    }
    else {
    
        header("Location:Multiple_choice_Question.php");
    }
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}
}

?>