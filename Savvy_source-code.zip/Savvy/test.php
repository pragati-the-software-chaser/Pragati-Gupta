<?php
    $total_months = 13;
    $years = $total_months / 12;
    $years = number_format($years);
    $months = $total_months % 12;
    if ( $years == 0 ) {
    $message = $months . " months";
    } else if ( $months == 0 ) {
    $message = $years . " years";
    } else {
    $message = $years . " years, and " . $months . " months";
    }

?>