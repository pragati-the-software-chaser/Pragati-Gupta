<?php
require 'DB_Configuration/Configuration.php';
session_start();


$user=$_SESSION['user'];
$user_email=$_SESSION['email'];
$courseName = $_SESSION['course_name'] ;

$quiz_name = $_SESSION['quiz_name'];

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiple Choice</title>
    <link rel="stylesheet" href="Multiple_choice_Question.css">
</head>
<body>
                <h1>Test / Create Test  / Name of the Test</h1>
    <b><center> <lable for = "course_name" class="subheading">Course Name:</lable><?php echo $courseName  ?><br>
        <lable for = "quiz_name"class="subheading">Quiz Name:</lable><?php echo $quiz_name  ?></center></b> 
        <div class="container_of_multiple_questions">
            <form method = "POST">
                
            <div class="test_question_types">
                <ul>
                <li><button class="multiple_choice_button" name = "multiple_choice_button">Multiple Choice</button></li>
                <li><button class="true_false_button" name = "true_false_button">True/False</button></li>
                <li><button class="matching_questions_button" name = "matching_questions_button">Matching Questions</button></li>
                <li><button class="eassy_button" name = "eassy_button">Essay</button></li>
                <li><button class="fill_in_the_blank_button" name = "fill_in_the_blank_button">Fill in the Blank</button></li>
                <li><button class="short_answer_button" name = "short_answer_button">Short Answer</button></li>
                   <!-- <li><a href="#">Multiple Choice</a></li>
                    <li><a href="#">True/False</a></li>
                    <li><a href="#">Matching Questions</a></li>
                    <li><a href="#">Eassy</a></li>
                    <li><a href="#">Fill_in_the_blank</a></li>
                    <li><a href="#">Short Answer</a></li>-->
                </ul>
            </div>
            </form>
            <form method="POST">
            <div  class="Question_for_all_types">
                <h3>Question:</h3>
                <input type="text" name="Question" id="Question" placeholder="Type Question here">
            </div>   
        <?php if(isset($_POST["multiple_choice_button"])) :?>
            <div  class="option_of_multiple_choice_questions">
            <h3>Answer:</h3>
                <label for="answer_a">A.</label>
                <input type="text" name="answer_a" id="answer_a" placeholder="Type Answer here"><br>
                <label for="answer_b">B.</label>
                <input type="text" name="answer_b" id="answer_b" placeholder="Type Answer here"><br>
                <label for="answer_c">C.</label>
                <input type="text" name="answer_c" id="answer_c" placeholder="Type Answer here"><br>
                <label for="answer_d">D.</label>
                <input type="text" name="answer_d" id="answer_d" placeholder="Type Answer here"><br><br>
                <label for="answer_d">Correct Answer.</label>
                <input type="text" name="answer_correct" id="answer_a" placeholder="Type Correct Answer here"><br>
            </div>
            <button class="shuffle_button" name = "submit_multiChoice">Submit</button><br><br>
        <?php endif; ?>
        <?php if(isset($_POST["eassy_button"])) :?>
       <!--  <div  class="Essay" >
            <h3>Answer:</h3>
             <input type="text" name="answer_essay_question" id="answer_essay_question" placeholder="Type Answer here">
        </div>-->
        <br><br> 
        <button class="shuffle_button" name = "submit_essay">Submit</button><br><br> 
        <?php endif; ?>
        <?php if(isset($_POST["true_false_button"])) :?>
        <div  class="true_false">
            <h3>Answer:</h3>
                <label for = "answer_a_true">A. </label>
                <input type="text" name="answer_a_true" id="answer_a" value= "True"><br>
                <label for  = "answer_b_false">B. </label>
                <input type="text" name="answer_a_false" id="answer_a" value= "False"><br>
                 <label for="answer_d">Correct Answer.</label>
                <input type="text" name="answer_correct" id="answer_a" placeholder="Type Correct Answer here"><br>
          </div>
          <button class="shuffle_button" name = "submit_true_false">Submit</button><br><br>
          <?php endif; ?>
        <?php if(isset($_POST["matching_questions_button"])) :?>
        <div    class="matching_answers">
            <h3>Answer:</h3>
                    <label for="matching_option_a">A.</label>
                    <input type="text" name="matching_option_a" id="matching_option_a" placeholder="Type option A here">
                    <label for="matching_answer_a">a.</label>
                    <input type="text" name="matching_answer_a" id="matching_answer_a" placeholder="Type answer of A here"><br>
                    <label for="matching_option_b">B.</label>
                    <input type="text" name="matching_option_b" id="matching_option_b" placeholder="Type option B here">
                    <label for="matching_answer_b">b.</label>
                    <input type="text" name="matching_answer_b" id="matching_answer_b" placeholder="Type answer of B here"><br>
                    <label for="matching_option_c">C.</label>
                    <input type="text" name="matching_option_c" id="matching_option_c" placeholder="Type option C here">
                    <label for="matching_answer_c">c.</label>
                    <input type="text" name="matching_answer_c" id="matching_answer_c" placeholder="Type answer of C here"><br>
                    <label for="matching_option_d">D.</label>
                    <input type="text" name="matching_option_d" id="matching_option_d" placeholder="Type option D here">
                    <label for="matching_answer_d">d.</label>
                    <input type="text" name="matching_answer_d" id="matching_answer_d" placeholder="Type answer of D here"><br>
                    <button class="shuffle_button">Shuffle </button>
         </div>
         <button class="shuffle_button" name = "submit_matching_question">Submit</button><br><br>
         <?php endif; ?>
        <?php if(isset($_POST["fill_in_the_blank_button"])) :?>
        <div  >
            <p class="add_blank_space_button">Add blank space  use keyboard key "---". </p>
            <h3>Answer:</h3>
            <input type="text" name="answer_fill_in_the_blanks" id="answer_fill_in_the_blanks" placeholder="Type Answer here"><br>
        </div>
    
        <button class="shuffle_button" name = "submit_fill_blank">Submit</button><br><br>
<?php endif; ?>
<?php if(isset($_POST["short_answer_button"])) :?>
<div   class="short_answer" >
    <h3>Correct Answer:</h3>
     <input type="text" name="short_answer_correct" id="short_answer" placeholder="Type Answer here">
</div>
<button class="shuffle_button" name = "submit_short_answer">Submit</button><br><br>
<?php endif; ?>
<br>

</form>
</div>
    <footer>
        <ul>
            <li><a href="https://www.facebook.com/" >Facebook</a></li>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="#">Contact Us</a></li>
        </ul>
   
    </footer>

</body>
</html>

<?php

# Code for MultiChoice 
if(isset($_POST['submit_multiChoice'])) {
try{

$Question =  $_POST['Question'];
$answer_a =  $_POST['answer_a'];
$answer_b =  $_POST['answer_b'];
$answer_c =  $_POST['answer_c'];
$answer_d =  $_POST['answer_d'];
$answer_correct =  $_POST['answer_correct'];



$query= "insert into test_info values('$quiz_name','$Question','MultiChoice','$answer_a','$answer_b','$answer_c','$answer_d','$answer_correct')";

$query_run= mysqli_query($con,$query);

if($query_run)
{
                    
    echo'<script type ="text/javascript"> alert("Question Created") </script>';
}
else 
{
    echo'<script type ="text/javascript"> alert("Question Creation Failed Error!") </script>';
            
}
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}
}

# Code for True False 
if(isset($_POST['submit_true_false'])) {
  try{
   
    $Question =  $_POST['Question'];
    $answer_a =  $_POST['answer_a_true'];
    $answer_b =  $_POST['answer_a_false'];
    $answer_correct =  $_POST['answer_correct'];
    
    
    
    $query= "insert into test_info values('$quiz_name','$Question','TrueFalse','$answer_a','$answer_b',Null,Null,'$answer_correct')";
    
    $query_run= mysqli_query($con,$query);
    
    if($query_run)
    {
                        
        echo'<script type ="text/javascript"> alert("Question Created") </script>';
    }
    else 
    {
        echo'<script type ="text/javascript"> alert("Question Creation Failed Error!") </script>';
                
    }
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}
    }
    # Code for Essay 
    if(isset($_POST['submit_essay'])) {

    try {
        $Question =  $_POST['Question'];
        
        
        
        $query= "insert into test_info values('$quiz_name','$Question','Essay',Null,Null,Null,Null,Null)";
        
        $query_run= mysqli_query($con,$query);
        
        if($query_run)
        {
                            
            echo'<script type ="text/javascript"> alert("Question Created") </script>';
        }
        else 
        {
            echo'<script type ="text/javascript"> alert("Question Creation Failed Error!") </script>';
                    
        }
    }
    catch(Exception $e){
        $error_message = $e->getMessage();
        echo "<p>Error message: $error_message </p>";
    }
        }

        # Code for Fill in the blank 

        if(isset($_POST['submit_fill_blank'])) {

            try {
            $Question =  $_POST['Question'];
           
            $answer_correct =  $_POST['answer_fill_in_the_blanks'];
            
            
            
            $query= "insert into test_info values('$quiz_name','$Question','Fill in the blank',Null,Null,Null,Null,'$answer_correct')";
            
            $query_run= mysqli_query($con,$query);
            
            if($query_run)
            {
                                
                echo'<script type ="text/javascript"> alert("Question Created") </script>';
            }
            else 
            {
                echo'<script type ="text/javascript"> alert("Question Creation Failed Error!") </script>';
                        
            }
        }
        catch(Exception $e){
            $error_message = $e->getMessage();
            echo "<p>Error message: $error_message </p>";
        }
            
            }

            # Code for short answer

            if(isset($_POST['submit_short_answer'])) {
            try {

                $Question =  $_POST['Question'];
                $answer_correct =  $_POST['short_answer_correct'];
                
                
                
                $query= "insert into test_info values('$quiz_name','$Question','ShortAnswer',Null,Null,Null,Null,'$answer_correct')";
                
                $query_run= mysqli_query($con,$query);
                
                if($query_run)
                {
                                    
                    echo'<script type ="text/javascript"> alert("Question Created") </script>';
                }
                else 
                {
                    echo'<script type ="text/javascript"> alert("Question Creation Failed Error!") </script>';
                            
                }
            }
            catch(Exception $e){
                $error_message = $e->getMessage();
                echo "<p>Error message: $error_message </p>";
            }
                }
?>