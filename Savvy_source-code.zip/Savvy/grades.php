<?php
try {
session_start();

$user=$_SESSION['user'];
$courseInfo=$_SESSION['courseInfo'];
$AssessmentName=$_SESSION['AssessmentName'];

$dsn = 'mysql:host=localhost;dbname=savvy_db';
$db= new PDO($dsn,'root','');
$query= "select * from grades_info WHERE courseName= :course and AssessmentName = :name";
$statement = $db->prepare($query);
$statement->bindValue(':course',$courseInfo);
$statement->bindValue(':name',$AssessmentName);
$statement->execute();
$grades_list=$statement->fetchAll();
$statement->closeCursor();


}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grades</title>
    <link rel="stylesheet" href="grades.css">
</head>
<body>
 
    <main>
        <div class="container">
    
    <form action="/action_page.php" method="POST">
    <div>
   <h1>Course : <?php echo $courseInfo  ?></h1> <h1>Assignment Name : <?php echo $AssessmentName  ?></h1>
    </div>
    
    <div></div>
    
    </form>
    </div>
    </main>
    <div>
       <table>
           <tr>
               <th>Student Name</th>
               <th>Total No of Questions</th>
               <th>Correct Answers</th>
               <th>Incorrect Answers</th>
               <th>Grade</th>
            </tr>
            <?php foreach ($grades_list as $grade): ?>
            <tr>
                <td><?php echo $grade['StudentName'] ?></td>
                <td><?php echo $grade['Total_Question'] ?></td>
                <td><?php echo $grade['Correct_Answers'] ?></td>
                <td><?php echo $grade['Wrong_Answers'] ?></td>
                <td><?php echo $grade['Grade'] ?></td>
            </tr>
            <?php endforeach ?>
       </table>
       
    </div>
    <footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>
    
</body>
</html>