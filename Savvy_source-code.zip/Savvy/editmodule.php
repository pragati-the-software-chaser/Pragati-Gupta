<?php

try{
session_start();

$user=$_SESSION['user'];
$courseInfo=$_SESSION['courseInfo'];
$moduleName=$_SESSION['moduleName'];

$dsn = 'mysql:host=localhost;dbname=savvy_db';
$db= new PDO($dsn,'root','');
$query= "select * from module_info WHERE courses= :course and moduleName=:moduleName";
$statement = $db->prepare($query);
$statement->bindValue(':course',$courseInfo);
$statement->bindValue(':moduleName',$moduleName);
$statement->execute();
$modulelist=$statement->fetchAll();
$statement->closeCursor();

}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Modules</title>
    <link rel="stylesheet" href="editmodule.css">
</head>
<body>
    

<div>
   <h1>Course : <?php echo $courseInfo  ?></h1> <h1>Module Name : <?php echo $moduleName  ?></h1>
</div>
<main>
    <div class="container">
    <form action="" method="post" enctype="multipart/form-data">
<table class="center">
    <tr>
        <th >Topic Name</th>
        <th class="content" >Content</th>
        <th>Detele Content</th>
    </tr>
    <?php 
        foreach ($modulelist as $module): 
        $topicName = $module['topicName'];
        $dir = $user . "\\" . $courseInfo . "\\module" . "\\" . $moduleName . "\\" . $topicName;
        $files = scandir($dir);
        $current_dir = getcwd();
        $target_dir = $current_dir . "\\" . $user . "\\" .$courseInfo  . "\\module" ."\\" . $moduleName . "\\" . $topicName . "\\" ;?>
    <?php foreach ($files as $file): ?>
    <?php if ($file != ".." & $file != "."): ?>      
    <tr>
        <td ><?php echo $topicName; ?></a></td>
        <td ><a href="<?php echo $target_dir . $file; ?>"><?php echo $file; ?></a></td>
        <td class="delete_button" ><button type="submit" name = "delete_button">Delete</button></td>
        <input hidden name = "targetFile" value = "<?php echo $target_dir . $file;?>">
    </tr>
    <?php endif; ?>
    <?php endforeach; ?>
    <?php if($module['topicURL']):?>      
    <tr>
        <td ><?php echo $topicName; ?></a></td>
        <td ><a href="<?php echo $module['topicURL']; ?>" name= "url_anchor"><?php echo $module['topicURL']; ?></a></td>
        <td class="delete_button" ><button type="submit" name = "url_delete_button">Delete</button></td>
        <input hidden name = "targetURL" value = "<?php echo $topicName;?>">
    </tr>
    <?php endif; ?>
    <?php endforeach; ?>

</table>
<br>
  </form>
</div>
</main>

<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>

<?php


if(isset($_POST['delete_button'])) {
    unlink($_POST['targetFile']);
    header("Location:editModule.php");

}

if(isset($_POST['url_delete_button'])) {
    echo'<script type ="text/javascript"> alert("I am here") </script>';
    $topicName = $_POST['targetURL'];
    $query= "update  module_info set topicURL = Null WHERE courses= :courseName and moduleName = :moduleName and topicName = :topicName";
    $dsn = 'mysql:host=localhost;dbname=savvy_db';
    $db= new PDO($dsn,'root','');
    $statement = $db->prepare($query);
    $statement->bindValue(':courseName',$courseInfo);
    $statement->bindValue(':moduleName',$moduleName);
    $statement->bindValue(':topicName',$topicName);
    $statement->execute();
    $statement->closeCursor();
    header("Location:editModule.php");
    
}


?>