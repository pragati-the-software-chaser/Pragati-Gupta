<?php
require 'DB_Configuration/Configuration.php';
session_start();

$user=$_SESSION['user'];
$user_email=$_SESSION['email'];
$courselist= $_SESSION['courseList'];

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Assessment</title>
    <link rel="stylesheet" href="view_assessment.css">
</head>
<body>
    <h1>Assessment/ View Assessment</h1>
<main>

    <div class="container">

<form action="" method="post" enctype="multipart/form-data">


<lable for = "course_name" >Course Name:</lable>

<select class="option" name="course_name" id="course_name"  value = "<?php echo $_SESSION['courseInfo'];?>">
            <?php foreach ($courselist as $Courses): ?>
                <option><?php echo $Courses['courses']; ?> </option>
            <?php endforeach; ?>
            </select><br>
            <div>
                <label for="assessment_type">Assessment Type:</label>
                <select name="assessment_type" id="assessment_type" >
                    <option value="discussion">Discussion</option>
                    <option value="Quiz">Quiz</option>
                    <option value="assignment">Assignment</option>

                </select>

</div>
<button id="getassessment" value="getassessment" name="getassessment">Get Assessment</button>
</form>
<?php
   if(isset($_POST['getassessment'])) {
    try{
        $courseName = $_POST['course_name'];
        $_SESSION['courseInfo'] = $courseName;
        $assessment_type = $_POST['assessment_type'];
        $dsn = 'mysql:host=localhost;dbname=savvy_db';
        $db= new PDO($dsn,'root','');
        $query= "select * from assessment_info WHERE courseName= :course and Assessment_Type = :type";
        $statement = $db->prepare($query);
        $statement->bindValue(':course',$courseName);
        $statement->bindValue(':type',$assessment_type);
        $statement->execute();
        $Assessment_list=$statement->fetchAll();
        $_SESSION['Assessment_list'] =  $Assessment_list;
        $statement->closeCursor();
        
    }
    catch(Exception $e){
        $error_message = $e->getMessage();
        echo "<p>Error message: $error_message </p>";
    }
}

?>
<form  method="post" enctype="multipart/form-data">
<label for ="module_name">Assessment Name:</label>
<select class="option" name="assess_name" id="assess_name"  >
            <?php foreach ($Assessment_list as $asessment): ?>
                <option><?php echo $asessment['Assessment_Name']; ?> </option>
            <?php endforeach; ?>
            </select><br>


<button id="edit_button" value="upload" name="edit_button">View</button>
</form>

</div>
</main>

<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>
<?php
   if(isset($_POST['edit_button'])) {
       try {
    
    $_SESSION['AssessmentName'] = $_POST["assess_name"];
    $Assessment_list = $_SESSION['Assessment_list'];
    foreach ($Assessment_list as $asessment):
        if ($asessment["Assessment_Name"] == $_POST["assess_name"]) :
            print_r($asessment["Due Date"]);
            $_SESSION['DueDate'] = $asessment["Due Date"];
            $_SESSION['totalScore'] = $asessment["Total Score"];
            $assessment_type= $asessment["Assessment_Type"];
            $Question= $asessment["Question"];
        endif;
    endforeach; 
    if ($assessment_type == "Assignment") : 
        header("Location:view_assignment.php");
    endif;
    if ($assessment_type == "Discussion") : 
        $_SESSION["Question"] = $Question;
        header("Location:view_discussion.php");
    endif;
    if ($assessment_type == "Quiz") : 
        $_SESSION["Question"] = $Question;
        header("Location:viewQuiz.php");
    endif;
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}
    
}

?>
