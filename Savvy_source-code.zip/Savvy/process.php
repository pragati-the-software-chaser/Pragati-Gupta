<?php
//get the data from the form
  
    if(isset($_POST['submit_button']))
    {
        //echo '<script type="text/javascript"> alert("Sign up button clicked") </script>';
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $number_street = $_POST['number_street'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $zip_code= $_POST['zip_code'];
        $check_in_date= $_POST['check_in_date'];
        $check_out_date= $_POST['check_out_date'];
        $number_of_people= $_POST['number_of_people'];
        $phone= $_POST['phone'];
        $email_address= $_POST['email_address'];
        $payment_method= $_POST['payment_method'];
        $card_number= $_POST['card_number'];
        $special_request= $_POST['special_request'];  
    }
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Confirmation Page</title>
    <link rel="stylesheet" href="Reservation_form.css">
</head>
<body>
<main>
    <h1>Thank you <?php echo $first_name,' ', $last_name; ?> for your reservation</h1>
    <p>The following are the information that you entered:</p>
    <label>Number & Street</label>
    <span><?php echo $number_street; ?></span><br>
    <label>City</label>
    <span><?php echo $city; ?></span><br>
    <label>State</label>
    <span><?php echo $state; ?></span><br>
    <label>Zip Code</label>
    <span><?php echo $zip_code; ?></span><br>
    <label>Check In Date</label>
    <span><?php echo $check_in_date; ?></span><br>
    <label>Check Out Date</label>
    <span><?php echo $check_out_date; ?></span><br>
    <label>Number of People</label>
    <span><?php echo $number_of_people; ?></span><br>
    <label>Email</label>
    <span><?php echo $email_address; ?></span><br>
    <label>Phone Number</label>
    <span><?php echo $phone; ?></span><br>
    <label>Credit Card</label>
    <span><?php echo $payment_method; ?></span><br>
    <label>Card Number</label>
    <span><?php echo $card_number; ?></span><br>
    <label>Special Request</label>
    <span><?php echo $special_request; ?></span><br>
    </main>
</body>
</html>
