<?php
require 'DB_Configuration/Configuration.php';
session_start();

$user=$_SESSION['user'];
$user_email=$_SESSION['email'];
$courselist= $_SESSION['courseList'];
    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Module</title>
    <link rel="stylesheet" href="Create_Module.css">
</head>
<body>
   <center> <h1>Module/Create Modules</h1></center>
<main>
    <div class="container">

<form action="create_module.php" method="post" enctype="multipart/form-data">
<lable for = "course_name" >Course Name:</lable>
<select class="option" name="course_name" id="course_name"  >
            <?php foreach ($courselist as $Courses): ?>
                <option><?php echo $Courses['courses']; ?> </option>
            <?php endforeach; ?>
            </select><br>


<label for ="module_name">Module Name:</label>
<input type="text" name="module_name" id="module_name" placeholder="Type Module Name" required> <br>

<label for ="topic_name">Topic Name:</label>
<input type="text" name="topic_name" id="module_name" placeholder="Type Topic Name" > <br>

<label for ="topic_url">Topic online url:</label>
<input type="text" name="topic_url" id="module_name" placeholder="Type Topic Url" > <br>

<label for ="upload_file">Upload File:</label>
<input type="file" id="fileToUpload" name="fileToUpload"><br>

<button id="upload_button" value="upload" name="upload_button">Create</button>
</form>
</form>

</div>
</main>

<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>
<?php

// Check if image file is a actual image or fake image
if(isset($_POST['upload_button'])) {

  try {
    $user=$_SESSION['user'];
    $courseName= $_POST['course_name'];
    $moduleName = $_POST['module_name'];
    $topicName = $_POST['topic_name'];
    $topicUrl = $_POST['topic_url'];


    $current_dir = getcwd();
 
    if ( !is_dir( $user ) ) {
        $folderCreated = mkdir($user);
        if(!$folderCreated){
            echo'<script type ="text/javascript"> alert("Failed to create folder") </script>';
        }
    }
    if ( !is_dir( $user . "\\" . $courseName ) ) {
        $folderCreated = mkdir($user . "\\" . $courseName);
        if(!$folderCreated){
            echo'<script type ="text/javascript"> alert("Failed to create folder") </script>';
        }
    }

    if ( !is_dir( $user . "\\" . $courseName . "\\module" ) ) {
        $folderCreated = mkdir($user . "\\" . $courseName . "\\module");
        if(!$folderCreated){
            echo'<script type ="text/javascript"> alert("Failed to create folder") </script>';
        }
    }
    
    if ( !is_dir( $user . "\\" .$courseName . "\\module" . "\\" . $moduleName ) ) {
        $folderCreated = mkdir($user . "\\" .$courseName . "\\module" . "\\" . $moduleName);
        if(!$folderCreated){
            echo'<script type ="text/javascript"> alert("Failed to create folder") </script>';
        }
    }
    if ( !is_dir( $user . "\\" .$courseName . "\\module" . "\\" . $moduleName . "\\" . $topicName ) ) {
        $folderCreated = mkdir($user . "\\" .$courseName . "\\module" . "\\" . $moduleName . "\\" . $topicName);
        if(!$folderCreated){
            echo'<script type ="text/javascript"> alert("Failed to create folder") </script>';
        }
    }
    

    $target_dir = $current_dir . "\\" . $user . "\\" .$courseName . "\\module" . "\\" . $moduleName . "\\" . $topicName . "\\";
 
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    move_uploaded_file( $_FILES['fileToUpload']['tmp_name'], $target_file);
    echo'<script type ="text/javascript"> alert("File Uploaded successfully") </script>';

  

      
    $query= "insert into module_info values('$courseName','$moduleName','$topicName','$topicUrl')";

    $query_run= mysqli_query($con,$query);

    if($query_run)
    {
                        
        echo'<script type ="text/javascript"> alert("Module Created") </script>';
        $_SESSION['courseInfo'] = $courseName;
        $_SESSION['moduleName'] = $moduleName;
        header('Location:editmodule.php');
    }
    else 
    {
        echo'<script type ="text/javascript"> alert("Module Creation Failed Error!") </script>';
                
    }
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}
        
}
?>