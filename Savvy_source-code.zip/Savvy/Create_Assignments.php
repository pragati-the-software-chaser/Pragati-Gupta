<?php
require 'DB_Configuration/Configuration.php';
session_start();


$user=$_SESSION['user'];
$user_email=$_SESSION['email'];
$courseName = $_SESSION['course_name'] ;

    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Assignment</title>
    <link rel="stylesheet" href="Create_Module.css">
</head>
<body>
    
<main>
    <div class="container">

<form  method="POST"  enctype="multipart/form-data">
    <h2>Assessment / Create Assignment</h2><br>
<lable for = "course_name">Course Name: </lable><?php echo $courseName  ?><br>

</select><br>
<label for ="assignment_name">Assignment Name:</label>
<input type="text" name="assignment_name" id="assignment_name" placeholder="Type Assignment Name"> <br><br>
<label for ="total_score">Total Score:</label>
<input type="text" name="total_score" id="total_score" placeholder="Type Total Score"> <br><br>
<label for ="date_assignment">Due Date</label>
<input type="date" name="date_assignment" id="date_assignment" ><br><br>


<label for ="fileToSet">Upload File:</label>
<input type="file" id="fileToSet" name="fileToSet"><br>

<button id="submit_button" name="create_assignment">Create</button>

</form >

</div>
</main>

<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>


<?php

if(isset($_POST['create_assignment'])) {
try {

$user=$_SESSION['user'];
$assignment_name = $_POST['assignment_name'];
$due_date =  $_POST['date_assignment'];
$total_score =  $_POST['total_score'];
$current_dir = getcwd();

if ( !is_dir( $user ) ) {
    $folderCreated = mkdir($user);
    if(!$folderCreated){
        echo'<script type ="text/javascript"> alert("Failed to create folder") </script>';
    }
}
if ( !is_dir( $user . "\\" . $courseName ) ) {
    $folderCreated = mkdir($user . "\\" . $courseName);
    if(!$folderCreated){
        echo'<script type ="text/javascript"> alert("Failed to create folder") </script>';
    }
}
if ( !is_dir( $user . "\\" . $courseName . "\\assessment" ) ) {
    $folderCreated = mkdir($user . "\\" . $courseName . "\\assessment");
    if(!$folderCreated){
        echo'<script type ="text/javascript"> alert("Failed to create folder") </script>';
    }
}
if ( !is_dir( $user . "\\" .$courseName . "\\assessment" . "\\" . $assignment_name ) ) {
    $folderCreated = mkdir($user . "\\" .$courseName . "\\assessment" . "\\" . $assignment_name);
    if(!$folderCreated){
        echo'<script type ="text/javascript"> alert("Failed to create folder") </script>';
    }
}


$target_dir = $current_dir . "\\" . $user . "\\" .$courseName . "\\assessment" . "\\" . $assignment_name . "\\";
echo'<script type ="text/javascript"> alert($_FILES) </script>';

$target_file = $target_dir . basename($_FILES["fileToSet"]["name"]);
$uploadOk = 1;

move_uploaded_file( $_FILES['fileToSet']['tmp_name'], $target_file);
echo'<script type ="text/javascript"> alert("File Uploaded successfully") </script>';



  
$query= "insert into assessment_info values('$courseName','Assignment','$assignment_name',NULL,'$due_date',$total_score)";

$query_run= mysqli_query($con,$query);

if($query_run)
{   
    echo'<script type ="text/javascript"> alert("Assignment Created") </script>';
    $_SESSION['courseInfo'] = $courseName;
    $_SESSION['AssessmentName'] = $assignment_name;
    $_SESSION['DueDate'] = $due_date;
    $_SESSION['totalScore'] = $total_score;
    header('Location:view_assignment.php');
}
else 
{
    echo'<script type ="text/javascript"> alert("Assignment Creation Failed Error!") </script>';
            
}
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}
    
}
?>