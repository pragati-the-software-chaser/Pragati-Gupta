<?php
require 'DB_Configuration/Configuration.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="signup.css">
</head>
<body>
    <div class="container">
<main>
    <div class="box1">
        <h1>Sign Up</h1>
        <form  method="post" >
             <div class="form">     
             <label for="name">Name </label>
             <input type="text" name="name" id="name" placeholder="Type your name" required/><br><br>
             <label for="email">Email</label>
             <input type="email" name="email" id="email" placeholder="Type your email" required/><br><br>
             <label for="password">Password </label>
             <input type="password" name="password" id="password" placeholder="Type your password" required/> <br><br>
             <input type="checkbox" name="remember_me" id="remember_me"/>
             <label for="remember_me">Remember me</label><br><br>
             </div>
             <button class="submit_button" name="submit_button">Submit</button>     
</form>
<p class="login_connection">Already have an account?<a href="login.php"> Login</a> </p>
    </div>
    </div>
</main>
<footer>
    <div class="icons">
        <ul>
            <li><a href="https://www.facebook.com/">Facebook</a> </li>
            <li><a href="dashboard.php">Home</a> </li>
            <li><a href="contact_us.php">Contact Us</a> </li>
        </ul>
    </div>
</footer>
<?php
    if(isset($_POST['submit_button']))
    {
        $name = $_POST['name'];
        $email= $_POST['email'];
        $password= $_POST['password'];
        {
            $query= "select * from user_info WHERE name='$name'";

            $query_run= mysqli_query($con,$query);

            if(mysqli_num_rows($query_run)>0)
            {
                // there is already a user with the same username
                echo'<script type ="text/javascript"> alert("User already exists try another name") </script>';

            }
            {
                $query= "insert into user_info values('$name','$email','$password')";

                $query_run= mysqli_query($con,$query);

                if($query_run)
                {
                        
                    echo'<script type ="text/javascript"> alert("User registered successfully") </script>';
                    header("Location:Login.php");
                }
                else 
                {
                    echo'<script type ="text/javascript"> alert("Error!") </script>';
                }
            }
        }
    }

?>
</body>
</html>

