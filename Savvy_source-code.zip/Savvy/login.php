<?php
require 'DB_Configuration/Configuration.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="container">
<main>
    <div class="box1">
        <h1>Login</h1>
        <form action="Login.php" method="post" >
             <div class="form">     
             <label for="email">Email</label>
             <input type="email" name="email" id="email" placeholder="Type your email" required/><br><br>
             <label for="password">Password </label>
             <input type="password" name="password" id="password" placeholder="Type your password" required/> <br><br>
             <input type="checkbox" name="forgot_password" id="forgot_password"/>
             <label for="forgot_password">Forgot Password?</label><br><br>
             </div>
             <button class="login_button" name="login_button">Login</button>     
</form>
<p class="sign_up_now">Need an account<a href="signup.php"> Sign up now!</a> </p>
    </div>
    
    </div>
</main>
<footer>
    <div class="icons">
        <ul>
            <li><a href="https://www.facebook.com/">Facebook</a> </li>
            <li><a href="dashboard.php">Home</a> </li>
            <li><a href="contact_us.php">Contact Us</a> </li>
        </ul>
    </div>
</footer>
<?php
    if(isset($_POST['login_button']))
    {
        $email= $_POST['email'];
        $password= $_POST['password'];
        try{
        
            $dsn = 'mysql:host=localhost;dbname=savvy_db';
            $db= new PDO($dsn,'root','');
            $query= "select * from user_info WHERE email= :email";
            $statement = $db->prepare($query);
            $statement->bindValue(':email',$email);
            $statement->execute();
            $userInfo=$statement->fetch();
            $statement->closeCursor();
           $name_db=$userInfo[0];
           $email_db=$userInfo[1];
           $password_db=$userInfo[2];
        }
        catch(Exception $e){
            $error_message = $e->getMessage();
            echo "<p>Error message: $error_message </p>";
        }
           if($email_db==$email & $password_db==$password)
           {
               session_start();
               $_SESSION['user']=$name_db;
               $_SESSION['email']=$email_db;
            header("Location:dashboard.php");
           }
           else
           {
            echo'<script type ="text/javascript"> alert("\Email or Password are incorrect") </script>';
           } 
    }
?>
</body>
</html>