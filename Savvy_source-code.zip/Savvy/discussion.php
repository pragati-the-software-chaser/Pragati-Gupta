<?php
require 'DB_Configuration/Configuration.php';
session_start();
$courseName = $_SESSION["course_name"];


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Discussion</title>
    <link rel="stylesheet" href="discussion.css">
</head>
<body>
    <main>
    <form  method="POST"  enctype="multipart/form-data">
    <div class="container"></div>
    <h1>Assessment/Create Discussion</h1>
    <h3>Course Name : <?php echo $courseName ?></h3>
    <label for ="discussion_name">Discussion Name:</label>
    <input type="text" name="discussion_name" id="discussion_name" placeholder="Type Discussion Name"> <br><br>
    <label for ="total_score">Total Score:</label>
    <input type="text" name="total_score" id="total_score" placeholder="Type Total Score"> <br><br>

    <label for ="date_assignment">Due Date</label>
    <input type="date" name="date_assignment" id="date_assignment" ><br>
    <div  class="Question_for_all_types">
                <h3>Question:</h3>
                <textarea name="Question" rows="10" cols="30" id="Question"> </textarea>
    </div>   
            

    <div   class="submit_question_box" >
           
            <button id="submit_question" value="submit_question" name="submit_question">Submit</button>

    </div>
    </form>
    </main>
<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>
<?php
   if(isset($_POST['submit_question'])) {
 try {
    $Due_date = $_POST["date_assignment"];
    $discussion_name = $_POST["discussion_name"];
    $total_score = $_POST["total_score"];
    $courseName = $_SESSION["course_name"];
    $Question = $_POST["Question"];
    $query= "insert into assessment_info values('$courseName','Discussion','$discussion_name','$Question','$Due_date',$total_score)";

    $query_run= mysqli_query($con,$query);

    if($query_run)
    {
                        
        echo'<script type ="text/javascript"> alert("Discussion Created") </script>';
        $_SESSION['courseInfo'] = $courseName;
        $_SESSION['AssessmentName'] = $discussion_name;
        $_SESSION['DueDate'] = $Due_date;
        $_SESSION['totalScore'] = $total_score;
        $_SESSION["Question"] = $Question;
        header("Location:view_discussion.php");
    }
    else 
    {
        echo'<script type ="text/javascript"> alert("Discussion Creation Failed Error!") </script>';
                
    }
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}
}

?>
