<?php
require 'DB_Configuration/Configuration.php';
session_start();

$user=$_SESSION['user'];
$user_email=$_SESSION['email'];
$courselist= $_SESSION['courseList'];
    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Assessment</title>
    <link rel="stylesheet" href="create_assessment.css">
</head>
<body>
    <h1>Assessment/Create Assessment</h1>
<main>
    <div class="container">

<form action="create_assessment.php" method="post" enctype="multipart/form-data">
<lable for = "course_name" >Course Name:</lable>
<select class="option" name="course_name" id="course_name"  >
            <?php foreach ($courselist as $Courses): ?>
                <option><?php echo $Courses['courses']; ?> </option>
            <?php endforeach; ?>
            </select><br>
<div>
                <label for="assessment_type">Assessment Type:</label>
                <select name="assessment_type" id="assessment_type" >
                    <option value="discussion">Discussion</option>
                    <option value="quiz">Quiz</option>
                    <option value="assignment">Assignment</option>

                </select>

</div>
<br>
<div>

<button id="create_button" value="create" name="create_button">Create Assessment</button>


</div>
</form>
</div>
</main>

<footer>
    <ul>
        <li><a href="https://www.facebook.com/" >Facebook</a></li>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="contact_us.php">Contact Us</a></li>
    </ul>

</footer>


</body>
</html>
<?php

// Check if image file is a actual image or fake image
if(isset($_POST['create_button'])) {
    try {
    $assessment_type = $_POST['assessment_type'];

 
    $_SESSION["course_name"] = $_POST['course_name'];
   
    if($assessment_type == "discussion"){
        header("Location:discussion.php");
    }
    elseif($assessment_type == "quiz"){
        header("Location:create_quiz.php");
    }
    elseif($assessment_type == "assignment"){
        header("Location:Create_Assignments.php");
    }
}
catch(Exception $e){
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}

}

?>